<p align="center"><img src="https://dl.ascoos.com/images/ascoos.png" height=120 /></p>

***

# ASCOOS CMS License (Free Use) - AGL-F

## You are free to:

Share or copy and redistribute the material in any medium or format for any purpose, even commercially. 


## Attribution 

You must give appropriate credit , provide a link to the license, and indicate if changes were made .
You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.


## NoDerivatives

If you remix, transform, or build upon the material, you may not distribute the modified material.

## No additional restrictions

You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.
